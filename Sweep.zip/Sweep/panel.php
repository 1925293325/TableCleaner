<?php
/**
 * Sweep 后台面板
 * 
 * @package Sweep
 */

if (!defined('__TYPECHO_ROOT_DIR__')) exit;
if (!defined('__TYPECHO_ADMIN__')) define('__TYPECHO_ADMIN__', true);

require_once __TYPECHO_ROOT_DIR__ . '/admin/common.php';
require_once __TYPECHO_ROOT_DIR__ . '/admin/header.php';
require_once __TYPECHO_ROOT_DIR__ . '/admin/menu.php';

$db = Typecho_Db::get();
$prefix = $db->getPrefix();

// 处理操作
if (isset($_GET['do']) && in_array($_GET['do'], array('drop', 'truncate'))) {
    try {
        $table = isset($_GET['table']) ? $_GET['table'] : '';
        if (!preg_match('/^' . preg_quote($prefix) . '[a-zA-Z0-9_]+$/', $table)) {
            throw new Exception('表名非法');
        }
        
        if ($_GET['do'] == 'drop') {
            $db->query("DROP TABLE IF EXISTS `{$table}`");
            header('Location: ' . Helper::options()->adminUrl . 'extending.php?panel=Sweep%2Fpanel.php&msg=deleted');
            exit;
        } elseif ($_GET['do'] == 'truncate') {
            $db->query("TRUNCATE TABLE `{$table}`");
            header('Location: ' . Helper::options()->adminUrl . 'extending.php?panel=Sweep%2Fpanel.php&msg=truncated');
            exit;
        }
    } catch (Exception $e) {
        header('Location: ' . Helper::options()->adminUrl . 'extending.php?panel=Sweep%2Fpanel.php&msg=error&errmsg=' . urlencode($e->getMessage()));
        exit;
    }
}

// 查看详情
$viewTable = isset($_GET['view']) ? $_GET['view'] : '';
$isViewMode = !empty($viewTable) && preg_match('/^' . preg_quote($prefix) . '[a-zA-Z0-9_]+$/', $viewTable);

$tableData = array();
$tableStructure = array();
$tableInfo = array();

if ($isViewMode) {
    try {
        $tableStructure = $db->fetchAll("SHOW COLUMNS FROM `{$viewTable}`");
        $tableData = $db->fetchAll("SELECT * FROM `{$viewTable}` LIMIT 50");
        $count = $db->fetchObject("SELECT COUNT(*) as c FROM `{$viewTable}`")->c;
        $tableInfo = array(
            'name' => $viewTable,
            'short' => str_replace($prefix, '', $viewTable),
            'count' => $count
        );
    } catch (Exception $e) {
        $error = "无法读取表: " . $e->getMessage();
    }
}

$msg = isset($_GET['msg']) ? $_GET['msg'] : '';
$errmsg = isset($_GET['errmsg']) ? $_GET['errmsg'] : '';
?>

<style>
.sweep-wrap { max-width: 1200px; margin: 0 auto; padding: 24px; color: #e0e6ed; background: #1e2329; min-height: 100vh; }
.sweep-header { margin-bottom: 28px; padding-bottom: 16px; border-bottom: 1px solid #3d4652; }
.sweep-title { font-size: 22px; font-weight: 600; color: #fff; margin: 0 0 6px; letter-spacing: -0.3px; }
.sweep-subtitle { font-size: 14px; color: #9aa5b1; }

.alert { padding: 14px 18px; border-radius: 10px; font-size: 14px; margin-bottom: 24px; border-left: 4px solid; line-height: 1.5; }
.alert-success { background: #1a2f23; border-color: #2d8659; color: #7dd3a8; }
.alert-error { background: #2f1a1a; border-color: #a04545; color: #ffb3b3; }

.info-card { background: #252b33; border: 1px solid #3d4652; border-radius: 12px; padding: 18px 20px; margin-bottom: 24px; }
.info-title { font-size: 15px; font-weight: 600; color: #f0f4f8; margin-bottom: 8px; display: flex; align-items: center; gap: 8px; }
.info-text { font-size: 14px; color: #b0bac6; line-height: 1.6; }

.stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; margin-bottom: 28px; }
.stat-box { background: #252b33; border: 1px solid #3d4652; border-radius: 10px; padding: 20px; text-align: center; }
.stat-number { font-size: 32px; font-weight: 700; color: #fff; margin-bottom: 6px; }
.stat-label { font-size: 14px; color: #9aa5b1; font-weight: 500; }

.table-list { display: flex; flex-direction: column; gap: 12px; }
.table-row { background: #252b33; border: 1px solid #3d4652; border-radius: 10px; padding: 18px 20px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px; transition: all 0.2s ease; }
.table-row:hover { border-color: #4b5663; background: #2a3038; }
.table-main { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; }
.table-icon { width: 36px; height: 36px; background: #2d3640; border: 1px solid #3d4652; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0; }
.table-info { display: flex; flex-direction: column; gap: 6px; }
.table-name { font-family: "SF Mono", Monaco, Consolas, monospace; font-size: 16px; color: #f0f4f8; font-weight: 600; letter-spacing: -0.2px; }
.table-tags { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }

.tag { padding: 4px 10px; border-radius: 20px; font-size: 13px; font-weight: 500; white-space: nowrap; border: 1px solid; }
.tag-plugin { background: rgba(99, 102, 241, 0.1); color: #a5b4fc; border-color: rgba(99, 102, 241, 0.3); }
.tag-plugin.high { background: rgba(34, 197, 94, 0.1); color: #86ef9f; border-color: rgba(34, 197, 94, 0.3); }
.tag-plugin.medium { background: rgba(245, 158, 11, 0.1); color: #fcd34d; border-color: rgba(245, 158, 11, 0.3); }
.tag-plugin.low { background: rgba(148, 163, 184, 0.1); color: #94a3b8; border-color: rgba(148, 163, 184, 0.3); opacity: 0.8; }

.tag-status { background: #2d3640; color: #e0e6ed; border-color: #4b5663; }
.tag-status.empty { color: #86ef9f; }
.tag-status.data { color: #fcd34d; }

.hint-text { font-size: 13px; color: #9aa5b1; }
.hint-text.safe { color: #86ef9f; font-weight: 500; }
.hint-text.warn { color: #fcd34d; font-weight: 500; }

.actions { display: flex; gap: 10px; flex-wrap: wrap; }
.btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 8px; font-size: 14px; font-weight: 500; text-decoration: none; border: 1px solid transparent; cursor: pointer; transition: all 0.15s ease; white-space: nowrap; }
.btn-view { background: #3b82f6; color: #fff; border-color: #3b82f6; }
.btn-view:hover { background: #2563eb; border-color: #2563eb; }
.btn-clear { background: #f59e0b; color: #1e2329; border-color: #f59e0b; font-weight: 600; }
.btn-clear:hover { background: #d97706; border-color: #d97706; }
.btn-delete { background: #ef4444; color: #fff; border-color: #ef4444; }
.btn-delete:hover { background: #dc2626; border-color: #dc2626; }
.btn-back { background: #2d3640; color: #e0e6ed; border-color: #3d4652; }
.btn-back:hover { background: #3d4652; border-color: #4b5663; }

.detail-card { background: #252b33; border: 1px solid #3d4652; border-radius: 12px; padding: 24px; margin-bottom: 20px; }
.detail-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
.detail-title { font-size: 18px; color: #f0f4f8; font-family: monospace; font-weight: 600; margin-bottom: 6px; }
.detail-meta { color: #9aa5b1; font-size: 14px; }

.section-title { font-size: 14px; font-weight: 600; color: #9aa5b1; text-transform: uppercase; letter-spacing: 0.5px; margin: 24px 0 12px; padding-bottom: 8px; border-bottom: 1px solid #3d4652; }

.fields-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px; margin-bottom: 24px; }
.field-box { background: #1e2329; border: 1px solid #3d4652; border-radius: 8px; padding: 12px 14px; font-family: monospace; }
.field-name { color: #f0f4f8; font-size: 14px; font-weight: 600; margin-bottom: 4px; }
.field-type { color: #9aa5b1; font-size: 12px; }

.data-table-wrap { overflow-x: auto; border: 1px solid #3d4652; border-radius: 10px; background: #1e2329; }
.data-table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 14px; min-width: 600px; }
.data-table th { background: #252b33; color: #f0f4f8; font-weight: 600; padding: 12px 16px; text-align: left; border-bottom: 1px solid #3d4652; white-space: nowrap; }
.data-table td { padding: 10px 16px; border-bottom: 1px solid #2d333b; color: #e0e6ed; max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.data-table tr:last-child td { border-bottom: none; }
.data-table tr:hover td { background: #252b33; }

.empty-notice { text-align: center; padding: 40px; color: #9aa5b1; font-size: 15px; }

@media (max-width: 768px) {
    .sweep-wrap { padding: 16px; }
    .table-row { flex-direction: column; align-items: stretch; }
    .actions { width: 100%; }
    .actions .btn { flex: 1; justify-content: center; }
}
</style>

<div class="sweep-wrap">
    <div class="sweep-header">
        <h1 class="sweep-title"><?php echo $isViewMode ? '查看表结构' : '数据库清理'; ?></h1>
        <div class="sweep-subtitle"><?php echo $isViewMode ? '预览表数据与结构' : '智能识别并清理插件残留表'; ?></div>
    </div>

    <?php if ($msg): ?>
    <div class="alert alert-<?php echo $msg == 'error' ? 'error' : 'success'; ?>">
        <?php 
        if ($msg == 'deleted') echo '✓ 表已成功删除';
        elseif ($msg == 'truncated') echo '✓ 表数据已清空';
        elseif ($msg == 'error') echo '⚠ ' . htmlspecialchars($errmsg);
        ?>
    </div>
    <?php endif; ?>

    <?php if ($isViewMode): ?>
    
    <?php if (isset($error)): ?>
    <div class="alert alert-error">⚠ <?php echo $error; ?></div>
    <?php endif; ?>
    
    <div class="detail-card">
        <div class="detail-header">
            <div>
                <div class="detail-title"><?php echo htmlspecialchars($tableInfo['short']); ?></div>
                <div class="detail-meta">共 <?php echo $tableInfo['count']; ?> 条记录 · 显示前 50 条</div>
            </div>
            <div class="actions">
                <a href="?panel=Sweep%2Fpanel.php" class="btn btn-back">← 返回列表</a>
                <?php if ($tableInfo['count'] > 0): ?>
                <a href="<?php echo Helper::security()->getTokenUrl(Helper::options()->adminUrl . 'extending.php?panel=Sweep%2Fpanel.php&do=truncate&table=' . urlencode($viewTable)); ?>" 
                   class="btn btn-clear"
                   onclick="return confirm('确定清空此表的所有数据？');">清空数据</a>
                <?php endif; ?>
                <a href="<?php echo Helper::security()->getTokenUrl(Helper::options()->adminUrl . 'extending.php?panel=Sweep%2Fpanel.php&do=drop&table=' . urlencode($viewTable)); ?>" 
                   class="btn btn-delete"
                   onclick="return confirm('确定彻底删除此表吗？此操作不可恢复！');">删除表</a>
            </div>
        </div>

        <div class="section-title">表结构</div>
        <?php if (!empty($tableStructure)): ?>
        <div class="fields-grid">
            <?php foreach ($tableStructure as $field): ?>
            <div class="field-box">
                <div class="field-name"><?php echo htmlspecialchars($field['Field']); ?></div>
                <div class="field-type"><?php echo htmlspecialchars($field['Type']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="section-title">数据预览</div>
        <?php if (empty($tableData)): ?>
        <div class="empty-notice">暂无数据</div>
        <?php else: ?>
        <div class="data-table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <?php foreach (array_keys($tableData[0]) as $col): ?>
                        <th><?php echo htmlspecialchars($col); ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tableData as $row): ?>
                    <tr>
                        <?php foreach ($row as $val): ?>
                        <td title="<?php echo htmlspecialchars($val); ?>">
                            <?php 
                            $str = is_null($val) ? 'NULL' : htmlspecialchars($val);
                            echo strlen($str) > 50 ? substr($str, 0, 50) . '...' : $str; 
                            ?>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <?php else: ?>
    
    <div class="info-card">
        <div class="info-title">💡 使用提示</div>
        <div class="info-text">
            插件通过分析表名和字段特征智能识别归属。绿色标签表示高置信度（表名+字段均匹配），黄色表示中等置信度，灰色表示仅通过表名猜测。
            <br><strong>注意：</strong>删除前建议先查看表内容确认，操作不可逆。
        </div>
    </div>

    <?php
    $tables = array();
    $coreTables = array('contents', 'comments', 'metas', 'relationships', 'users', 'options', 'fields', 'searchcache');
    
    try {
        $result = $db->fetchAll("SHOW TABLES LIKE '{$prefix}%'");
        
        foreach ($result as $row) {
            $tableName = array_values($row)[0];
            $shortName = str_replace($prefix, '', $tableName);
            
            if (in_array($shortName, $coreTables)) continue;
            
            $count = $db->fetchObject("SELECT COUNT(*) as c FROM `{$tableName}`")->c;
            
            // 使用智能识别
            $detected = Sweep_Plugin::detectPlugin($tableName, $db);
            
            $tables[] = array(
                'name' => $tableName,
                'short' => $shortName,
                'count' => $count,
                'plugin' => $detected['name'],
                'confidence' => $detected['confidence'],
                'score' => $detected['score']
            );
        }
    } catch (Exception $e) {
        echo '<div class="alert alert-error">⚠ 数据库查询失败: ' . $e->getMessage() . '</div>';
    }
    
    $empty = $normal = 0;
    foreach ($tables as $t) {
        if ($t['count'] == 0) $empty++;
        else $normal++;
    }
    ?>

    <div class="stats-row">
        <div class="stat-box">
            <div class="stat-number"><?php echo $empty; ?></div>
            <div class="stat-label">可安全删除</div>
        </div>
        <div class="stat-box">
            <div class="stat-number"><?php echo $normal; ?></div>
            <div class="stat-label">需要确认</div>
        </div>
        <div class="stat-box">
            <div class="stat-number"><?php echo count($tables); ?></div>
            <div class="stat-label">总计</div>
        </div>
    </div>

    <?php if (empty($tables)): ?>
    <div class="empty-notice">
        <div style="font-size: 32px; margin-bottom: 12px;">🎉</div>
        <div>没有发现插件残留表</div>
        <div style="font-size: 13px; color: #9aa5b1; margin-top: 8px;">您的数据库很干净</div>
    </div>
    <?php else: ?>
    <div class="table-list">
        <?php foreach ($tables as $table): ?>
        <div class="table-row">
            <div class="table-main">
                <div class="table-icon">🗄️</div>
                <div class="table-info">
                    <div class="table-name"><?php echo htmlspecialchars($table['short']); ?></div>
                    <div class="table-tags">
                        <span class="tag tag-plugin <?php echo $table['confidence']; ?>">
                            <?php echo $table['plugin']; ?>
                            <?php if ($table['confidence'] == 'low'): ?>
                            <span style="opacity: 0.7; font-size: 11px;">(猜)</span>
                            <?php endif; ?>
                        </span>
                        <span class="tag tag-status <?php echo $table['count'] == 0 ? 'empty' : 'data'; ?>">
                            <?php echo $table['count'] == 0 ? '空表' : $table['count'] . '条数据'; ?>
                        </span>
                        <span class="hint-text <?php echo $table['count'] == 0 ? 'safe' : 'warn'; ?>">
                            <?php echo $table['count'] == 0 ? '✓ 可安全删除' : '⚠ 建议查看后操作'; ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <div class="actions">
                <a href="?panel=Sweep%2Fpanel.php&view=<?php echo urlencode($table['name']); ?>" class="btn btn-view">查看内容</a>
                <?php if ($table['count'] > 0): ?>
                <a href="<?php echo Helper::security()->getTokenUrl(Helper::options()->adminUrl . 'extending.php?panel=Sweep%2Fpanel.php&do=truncate&table=' . urlencode($table['name'])); ?>" 
                   class="btn btn-clear"
                   onclick="return confirm('确定清空表 <?php echo $table['short']; ?> 中的所有数据？');">清空</a>
                <?php endif; ?>
                <a href="<?php echo Helper::security()->getTokenUrl(Helper::options()->adminUrl . 'extending.php?panel=Sweep%2Fpanel.php&do=drop&table=' . urlencode($table['name'])); ?>" 
                   class="btn btn-delete"
                   onclick="return confirm('确定彻底删除表 <?php echo $table['short']; ?> 吗？此操作不可恢复！');">删除</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<?php
require_once __TYPECHO_ROOT_DIR__ . '/admin/copyright.php';
require_once __TYPECHO_ROOT_DIR__ . '/admin/footer.php';
?>
